package com.example.chatcommands;

import net.fabricmc.api.ModInitializer;

public class ExampleMod implements ModInitializer {
    @Override
    public void onInitialize() {
        ChatCommands.register();
    }
}
