package com.example.chatcommands;

import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.world.GameMode;

public class ChatCommands {

    public static void register() {
        ServerMessageEvents.CHAT_MESSAGE.register((message, sender, params) -> {
            ServerPlayerEntity p = sender.getPlayer();
            String msg = message.getSignedContent().getString().trim().toLowerCase();

            switch (msg) {

                // -------------------------
                // GAMEMODE COMMANDS
                // -------------------------
                case "%gamemode creative":
                case "%gmc":
                    p.changeGameMode(GameMode.CREATIVE);
                    p.sendMessage(Text.literal("§aGamemode set to Creative"));
                    break;

                case "%gamemode survival":
                case "%gms":
                    p.changeGameMode(GameMode.SURVIVAL);
                    p.sendMessage(Text.literal("§aGamemode set to Survival"));
                    break;

                case "%gamemode spectator":
                case "%gmsp":
                    p.changeGameMode(GameMode.SPECTATOR);
                    p.sendMessage(Text.literal("§aGamemode set to Spectator"));
                    break;

                case "%gamemode adventure":
                case "%gma":
                    p.changeGameMode(GameMode.ADVENTURE);
                    p.sendMessage(Text.literal("§aGamemode set to Adventure"));
                    break;


                // -------------------------
                // UTILITY COMMANDS
                // -------------------------
                case "%heal":
                    p.setHealth(p.getMaxHealth());
                    p.getHungerManager().setFoodLevel(20);
                    p.sendMessage(Text.literal("§aYou have been healed"));
                    break;

                case "%feed":
                    p.getHungerManager().setFoodLevel(20);
                    p.sendMessage(Text.literal("§aYou have been fed"));
                    break;

                case "%fly on":
                    p.getAbilities().allowFlying = true;
                    p.sendAbilitiesUpdate();
                    p.sendMessage(Text.literal("§aFlight enabled"));
                    break;

                case "%fly off":
                    p.getAbilities().allowFlying = false;
                    p.getAbilities().flying = false;
                    p.sendAbilitiesUpdate();
                    p.sendMessage(Text.literal("§cFlight disabled"));
                    break;

                case "%kill":
                    p.kill();
                    break;

                case "%coords":
                    p.sendMessage(Text.literal("§eYour coords: §b" +
                            p.getBlockX() + " " + p.getBlockY() + " " + p.getBlockZ()));
                    break;


                // -------------------------
                // TELEPORT COMMANDS
                // -------------------------
                case "%spawn":
                    p.teleport(p.getServer().getOverworld(),
                            p.getServer().getOverworld().getSpawnPos().getX(),
                            p.getServer().getOverworld().getSpawnPos().getY(),
                            p.getServer().getOverworld().getSpawnPos().getZ(),
                            p.getYaw(), p.getPitch());
                    p.sendMessage(Text.literal("§aTeleported to spawn"));
                    break;

                case "%top":
                    int x = p.getBlockX();
                    int z = p.getBlockZ();
                    int y = p.getServer().getOverworld().getTopY();
                    p.teleport(p.getServer().getOverworld(), x, y, z, p.getYaw(), p.getPitch());
                    p.sendMessage(Text.literal("§aTeleported to top"));
                    break;


                // -------------------------
                // FUN COMMANDS
                // -------------------------
                case "%explode":
                    p.getWorld().createExplosion(null, p.getX(), p.getY(), p.getZ(), 4f, false, null);
                    p.sendMessage(Text.literal("§cBoom!"));
                    break;

                case "%launch":
                    p.addVelocity(0, 2, 0);
                    p.sendMessage(Text.literal("§bLaunched!"));
                    break;

                case "%fire":
                    p.setOnFireFor(5);
                    p.sendMessage(Text.literal("§cYou are on fire!"));
                    break;

                case "%water":
                    p.setAir(300);
                    p.sendMessage(Text.literal("§bYou feel refreshed"));
                    break;

                default:
                    break;
            }
        });
    }
}
